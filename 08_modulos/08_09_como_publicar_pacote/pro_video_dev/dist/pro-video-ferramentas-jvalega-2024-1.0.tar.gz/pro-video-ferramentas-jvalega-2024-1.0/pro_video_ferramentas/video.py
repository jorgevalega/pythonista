def iniciar_gravacao():
    print('Iniciando gravação')